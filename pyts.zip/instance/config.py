PASSWORD='x--pay_nzQmnKJxi'
SECRET_KEY='SREZFsMb-xEQqP2H24o'
SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root@localhost/egofin'
SQLALCHEMY_TRACK_MODIFICATIONS=True